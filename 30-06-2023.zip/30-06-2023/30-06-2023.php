<?php
    echo "first number is:"; 
    $a1=10;
    echo $a1 ,"<br>";
    echo "second number is:"; 
    $a2=20;
    echo $a2 ,"<br>";
    $a3=$a1+$a2;
    echo "total:";
    echo $a3;
?>